declare module 'digest-fetch';
